import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

/**
 * @author Guadalupe
 */
public class DesvEst {

    public DesvEst() {
    }
    

    /**
     * @param media 
     * @param datalist 
     * @param n
     */ 
    public double getDesvEstd(String[] dataList, double media, double n) {

        double suma=0;
        for(int x=0; x<dataList.length; x++){
            suma = (double) (suma + (pow((Double.parseDouble(dataList[x])- media),2)));
        }

        double d= (suma/(n-1));
        double des = sqrt(d);
        
        return des;
    }
}
